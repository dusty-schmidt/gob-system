from dataclasses import dataclass
from ...base.downloader import BaseDownloader

@dataclass
class ServeoDownloader(BaseDownloader):
    """Downloader for Serveo"""
    pass