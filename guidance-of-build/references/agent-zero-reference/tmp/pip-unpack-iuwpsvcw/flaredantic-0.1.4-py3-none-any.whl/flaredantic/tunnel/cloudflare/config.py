from dataclasses import dataclass
from ...base.config import BaseConfig

@dataclass
class FlareConfig(BaseConfig):
    """Configuration for Cloudflare tunnel"""
    pass