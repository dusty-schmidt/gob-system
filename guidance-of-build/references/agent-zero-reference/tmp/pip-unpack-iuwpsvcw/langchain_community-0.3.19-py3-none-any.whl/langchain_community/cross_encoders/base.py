from langchain.retrievers.document_compressors.cross_encoder import BaseCrossEncoder

__all__ = ["BaseCrossEncoder"]
