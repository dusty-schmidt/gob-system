__version__ = "1.0.5"  # pragma: no cover
